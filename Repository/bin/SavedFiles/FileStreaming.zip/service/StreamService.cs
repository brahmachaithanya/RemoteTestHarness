///////////////////////////////////////////////////////////////////
// Strings.cs - WCF Strings Service in Self Hosted Configuration //
//                                                               //
// Jim Fawcett, CSE775 - Distributed Objects, Spring 2009        //
///////////////////////////////////////////////////////////////////
/*
 * Note:
 *   Uses Programmatic configuration, no app.config file used.
 *   Uses ChannelFactory to create proxy programmatically.   
 */

using System;
using System.IO;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace CSE681
{
  [ServiceBehavior]
  public class StreamService : IStreamService
  {
    string filename = "defaultName";
    string savePath = ".\\SavedFiles";
    int BlockSize = 1024;
    byte[] block;

    StreamService()
    {
      block = new byte[BlockSize];
    }
    public void upLoadFileName(string name)
    {
      Console.Write("\n  received filename: \"{0}\"", name);
      filename = name;
    }

    public void upLoadFile(Stream fileStream)
    {
      filename = Path.Combine(savePath,filename);
      Console.Write("\n  received stream");
      if(!Directory.Exists(savePath))
        Directory.CreateDirectory(savePath);
      using (var outputStream = new FileStream(filename, FileMode.Create))
      {
        while (true)
        {
          int bytesRead = fileStream.Read(block, 0, BlockSize);
          if (bytesRead > 0)
            outputStream.Write(block, 0, bytesRead);
          else
            break;
        }
      }
    }

    public void upLoadFile(FileUpLoadMessage msg)
    {
      filename = msg.filename;
      upLoadFile(msg.upStream);
    }

    public void downLoadFileName(string name)
    {
    }

    public void downLoadFile(Stream fileStream)
    {
    }

    static ServiceHost CreateServiceChannel(string url)
    {
      // SecurityMode options are:
      // - None
      // - Message (default)
      // - Transport
      // - TransportWithMessageCredential

      SecurityMode securityMode = SecurityMode.None;

      // ReliableSession is a property provided by bindings that support
      // transport-level session.  If set to true, the service will 
      // terminate after 10 minutes of inactivity.

      bool reliableSession = false;

      BasicHttpBinding binding = new BasicHttpBinding();
      binding.TransferMode = TransferMode.Streamed;
      binding.MaxReceivedMessageSize = 50000000;
      Uri baseAddress = new Uri(url);
      Type service = typeof(CSE681.StreamService);
      ServiceHost host = new ServiceHost(service, baseAddress);
      host.AddServiceEndpoint(typeof(IStreamService), binding, baseAddress);
      return host;
    }

    public static void Main()
    {
      ServiceHost host = CreateServiceChannel("http://localhost:8000/StreamService");

      host.Open();

      Console.Write("\n  SelfHosted File Stream Service started");
      Console.Write("\n ========================================\n");
      Console.Write("\n  Press key to terminate service:\n");
      Console.ReadKey();
      Console.Write("\n");
    }
  }
}
