﻿///////////////////////////////////////////////////////////////
// Client.cs - WCF SelfHosted Strings Service client         //
//                                                           //
// Jim Fawcett, CSE775 - Distributed Objects, Spring 2008    //
///////////////////////////////////////////////////////////////
/*
 * Note:
 *   Uses Programmatic configuration, no app.config file used.
 *   Uses ChannelFactory to create proxy programmatically.   
 */

using System;
using System.IO;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace CSE681
{
  class Client
  {
    IStreamService channel;

    static IStreamService CreateServiceChannel(string url)
    {
      BasicHttpBinding binding = new BasicHttpBinding();
      binding.TransferMode = TransferMode.Streamed;
      EndpointAddress address = new EndpointAddress(url);

      ChannelFactory<IStreamService> factory
        = new ChannelFactory<IStreamService>(binding, address);
      return factory.CreateChannel();
    }

    void uploadFile(string filename)
    {
      //channel.upLoadFileName(filename);
      using (var inputStream = new FileStream(filename, FileMode.Open))
      {
        FileUpLoadMessage msg = new FileUpLoadMessage();
        msg.filename = filename;
        msg.upStream = inputStream;
        channel.upLoadFile(msg);
      }
    }
    static void Main()
    {
      Console.Write("\n  Client of SelfHosted Strings service");
      Console.Write("\n ======================================\n");

      Client clnt = new Client();
      clnt.channel = CreateServiceChannel("http://localhost:8000/StreamService");

      clnt.uploadFile("test.txt");
      clnt.uploadFile("Channel_Client_Copy.exe");

      Console.Write("\n\n  Press key to terminate client");
      Console.ReadKey();
      Console.Write("\n\n");
      ((IChannel)clnt.channel).Close();
    }
  }
}
