﻿///////////////////////////////////////////////////////////////////////////
// IStreamService.cs - WCF Stream Service in Self Hosted Configuration   //
//                                                                       //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Summer 2009     //
///////////////////////////////////////////////////////////////////////////

using System;
using System.IO;
using System.ServiceModel;

namespace CSE681
{
  [ServiceContract(Namespace = "http://CSE681")]
  public interface IStreamService
  {
    [OperationContract(IsOneWay = true)]
    void upLoadFileName(string name);
    //[OperationContract(IsOneWay=true)]
    //void upLoadFile(Stream fileStream);
    [OperationContract(IsOneWay=true)]
    void upLoadFile(FileUpLoadMessage msg);
    [OperationContract(IsOneWay=true)]
    void downLoadFileName(string name);
    [OperationContract]
    void downLoadFile(Stream fileStream);
  }

  [MessageContract]
  public class FileUpLoadMessage
  {
    [MessageHeader(MustUnderstand = true)]
    public string filename { get; set; }

    [MessageBodyMember(Order = 1)]
    public Stream upStream { get; set; }
  }
}